# MTA-Discord-Status
Discord Status Bot Of MTA:SA Server (v13) 🔥🔥

# Install Module 
`npm install`

# Setup Your Bot
`edit config.json`

# Start your Bot
`node index.js`
# Done !
![image](https://user-images.githubusercontent.com/67291533/133821937-6e0033fd-dada-464e-afbf-2830c31498c6.png)
![image](https://user-images.githubusercontent.com/67291533/133822039-65dba1af-cf1c-4ae7-a03a-47cc1c4bc78f.png)
![image](https://user-images.githubusercontent.com/67291533/133822071-22b0a16a-6a06-4dd5-b88f-33badf69edfe.png)
